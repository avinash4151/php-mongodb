<?php
	$m = new MongoClient();
	$db = $m->comedy;
	$collection = $db->cartoons;
?>